-- AUW Connect: shared office-hour appointment notifications
-- Uses the existing public.notifications table:
-- id, user_id, title, body, read_at, created_at
-- Run this once in Supabase SQL Editor.

CREATE OR REPLACE FUNCTION public.book_office_hour(
    p_office_hour_id uuid,
    p_topic text,
    p_student_note text
)
RETURNS uuid
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
    v_student_id uuid := auth.uid();
    v_faculty_id uuid;
    v_appointment_id uuid;
BEGIN
    IF v_student_id IS NULL OR current_user_role() <> 'student' THEN
        RAISE EXCEPTION 'Only signed-in students can book office hours.';
    END IF;

    SELECT faculty_id
      INTO v_faculty_id
      FROM public.office_hours
     WHERE id = p_office_hour_id
       AND is_available = true
     FOR UPDATE;

    IF NOT FOUND THEN
        RAISE EXCEPTION 'This office-hour slot is no longer available.';
    END IF;

    UPDATE public.office_hours
       SET is_available = false
     WHERE id = p_office_hour_id;

    INSERT INTO public.appointments (
        office_hour_id, faculty_id, student_id, topic, student_note, status
    ) VALUES (
        p_office_hour_id, v_faculty_id, v_student_id,
        COALESCE(NULLIF(p_topic, ''), 'Office-hour appointment'),
        p_student_note, 'pending'
    ) RETURNING id INTO v_appointment_id;

    INSERT INTO public.notifications (user_id, title, body)
    VALUES (
        v_faculty_id,
        'New office-hour appointment request',
        'A student has requested an office-hour appointment. Open Appointment Requests to review it.'
    );

    RETURN v_appointment_id;
END;
$$;

CREATE OR REPLACE FUNCTION public.respond_to_office_hour_appointment(
    p_appointment_id uuid,
    p_status text,
    p_faculty_note text DEFAULT ''
)
RETURNS uuid
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
    v_faculty_id uuid := auth.uid();
    v_student_id uuid;
    v_office_hour_id uuid;
    v_status text := lower(COALESCE(p_status, ''));
BEGIN
    IF v_faculty_id IS NULL OR current_user_role() <> 'faculty' THEN
        RAISE EXCEPTION 'Only signed-in faculty can respond to appointment requests.';
    END IF;
    IF v_status NOT IN ('approved', 'declined') THEN
        RAISE EXCEPTION 'Response must be approved or declined.';
    END IF;

    UPDATE public.appointments
       SET status = v_status,
           faculty_note = NULLIF(trim(COALESCE(p_faculty_note, '')), '')
     WHERE id = p_appointment_id
       AND faculty_id = v_faculty_id
       AND lower(status) = 'pending'
     RETURNING student_id, office_hour_id
          INTO v_student_id, v_office_hour_id;

    IF NOT FOUND THEN
        RAISE EXCEPTION 'Appointment request not found or it has already been answered.';
    END IF;

    IF v_status = 'declined' THEN
        UPDATE public.office_hours
           SET is_available = true
         WHERE id = v_office_hour_id
           AND faculty_id = v_faculty_id;
    END IF;

    INSERT INTO public.notifications (user_id, title, body)
    VALUES (
        v_student_id,
        CASE WHEN v_status = 'approved'
             THEN 'Office-hour appointment approved'
             ELSE 'Office-hour appointment declined' END,
        CASE WHEN v_status = 'approved'
             THEN 'Your office-hour appointment request has been approved. Open My Appointments for details.'
             ELSE 'Your office-hour appointment request was declined. You can choose another available time.' END
    );

    RETURN v_student_id;
END;
$$;

CREATE OR REPLACE FUNCTION public.cancel_office_hour_appointment(
    p_appointment_id uuid
)
RETURNS uuid
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
    v_student_id uuid := auth.uid();
    v_faculty_id uuid;
    v_office_hour_id uuid;
BEGIN
    IF v_student_id IS NULL OR current_user_role() <> 'student' THEN
        RAISE EXCEPTION 'Only the student who made the request can cancel it.';
    END IF;

    UPDATE public.appointments
       SET status = 'cancelled'
     WHERE id = p_appointment_id
       AND student_id = v_student_id
       AND lower(status) IN ('pending', 'approved')
     RETURNING faculty_id, office_hour_id
          INTO v_faculty_id, v_office_hour_id;

    IF NOT FOUND THEN
        RAISE EXCEPTION 'Appointment not found or it cannot be cancelled.';
    END IF;

    UPDATE public.office_hours
       SET is_available = true
     WHERE id = v_office_hour_id
       AND faculty_id = v_faculty_id;

    INSERT INTO public.notifications (user_id, title, body)
    VALUES (
        v_faculty_id,
        'Office-hour appointment cancelled',
        'A student has cancelled an office-hour appointment. The time slot is available again.'
    );

    RETURN v_faculty_id;
END;
$$;

REVOKE ALL ON FUNCTION public.book_office_hour(uuid, text, text) FROM PUBLIC;
REVOKE ALL ON FUNCTION public.respond_to_office_hour_appointment(uuid, text, text) FROM PUBLIC;
REVOKE ALL ON FUNCTION public.cancel_office_hour_appointment(uuid) FROM PUBLIC;
GRANT EXECUTE ON FUNCTION public.book_office_hour(uuid, text, text) TO authenticated;
GRANT EXECUTE ON FUNCTION public.respond_to_office_hour_appointment(uuid, text, text) TO authenticated;
GRANT EXECUTE ON FUNCTION public.cancel_office_hour_appointment(uuid) TO authenticated;
